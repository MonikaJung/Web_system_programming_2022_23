package com.example.productlist2;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {
    ArrayList<Product> productList=new ArrayList<>();

    public ProductService() {
    }

    public void seed(){
        productList.add(new Product(1, "Chleb", 1f, 5.20f, "pieczywo"));
        productList.add(new Product(2, "Masło", 2.5f, 7f, "nabiał"));
        productList.add(new Product(3, "Ser", 0.3f, 8.29f, "nabiał"));
    }

    private boolean isEmpty() {
        return productList.size() == 0;
    }

    public List<Product> getAllProduct() {
        return productList;
    }

    public void addProduct(Product Product) {
        productList.add(Product);
    }
    public Product getProductById(long id) {
        for(Product Product:productList){
            if(Product.getId()==id)
                return Product;
        }
        return null;
    }
    public Product getProduct(Product Product){
        return getProductById(Product.getId());
    }
    public void updateProduct(Product Product) {
        deleteProduct(Product);
        productList.add(Product);
    }
    public void deleteProduct(Product Product) {
        productList.remove(getProductById(Product.getId()));
    }
    public void deleteProductById(long id) {
        productList.remove(getProductById(id));
    }

}
