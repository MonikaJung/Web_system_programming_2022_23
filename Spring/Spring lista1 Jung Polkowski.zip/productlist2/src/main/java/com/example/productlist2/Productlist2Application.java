package com.example.productlist2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Productlist2Application {

    public static void main(String[] args) {
        SpringApplication.run(Productlist2Application.class, args);
    }

}
